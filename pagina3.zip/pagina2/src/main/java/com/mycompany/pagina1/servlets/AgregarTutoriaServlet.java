package com.mycompany.pagina1.servlets;

import Modelo.GestionarTutoria;
import Modelo.Tutoria;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AgregarTutoriaServlet")
public class AgregarTutoriaServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String nombre = request.getParameter("nombreCurso");
        String profesor = request.getParameter("nombreTutor");

        // Obtener o crear la lista desde la sesión
        HttpSession session = request.getSession();
        ArrayList<Tutoria> tutorias = (ArrayList<Tutoria>) session.getAttribute("tutoriasGuardadas");
        if (tutorias == null) {
            tutorias = new ArrayList<>();
        }

        // Agregar la nueva tutoría
        tutorias.add(new Tutoria(nombre, "", profesor));

        // Guardar la lista actualizada en la sesión
        session.setAttribute("tutoriasGuardadas", tutorias);

        response.sendRedirect("tutoriasGuardadas.jsp");
    }
}
