package com.mycompany.pagina1.servlets;

import Modelo.Tutoria;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

// Mapeamos el Servlet a la ruta "/buscar"
@WebServlet("/buscar")
public class BuscarTutoriaServlet extends HttpServlet {
    private static final String URL = "jdbc:mysql://localhost:3306/tutorias"; // Ajusta la BD
    private static final String USER = "root";  // Usuario de la BD
    private static final String PASSWORD = "";  // Contraseña de la BD

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtiene el parámetro de búsqueda
        String query = request.getParameter("query");
        List<Tutoria> resultados = new ArrayList<>();

        if (query != null && !query.trim().isEmpty()) {
            try {
                // Cargar el driver de MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Conectar a la base de datos
                try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
                     PreparedStatement ps = con.prepareStatement(
                        "SELECT nombre_tutoria, nombre_profesor FROM tutorias WHERE nombre_tutoria LIKE ? OR nombre_profesor LIKE ?")) {

                    // Configurar los parámetros de la consulta
                    ps.setString(1, "%" + query + "%");
                    ps.setString(2, "%" + query + "%");

                    try (ResultSet rs = ps.executeQuery()) {
                        // Recorrer los resultados y crear objetos Tutoria
                        while (rs.next()) {
                            String nombreTutoria = rs.getString("nombre_tutoria");
                            String nombreProfesor = rs.getString("nombre_profesor");
                            resultados.add(new Tutoria(nombreTutoria, nombreProfesor));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Enviar resultados a la vista JSP
        request.setAttribute("resultados", resultados);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Buscartutoria.jsp");
        dispatcher.forward(request, response);
    }
}
