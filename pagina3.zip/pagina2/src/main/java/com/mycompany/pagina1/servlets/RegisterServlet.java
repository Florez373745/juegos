package com.mycompany.pagina1.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener los datos enviados desde el formulario
        String usuario = request.getParameter("usuario");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validación simple de los datos
        if (usuario == null || usuario.isEmpty() || 
            email == null || email.isEmpty() || 
            password == null || password.isEmpty()) {
            
            request.setAttribute("error", "Todos los campos son obligatorios.");
            request.getRequestDispatcher("styles/register.jsp").forward(request, response);
            return;
        }

        // Crear la sesión y guardar datos
        HttpSession sesion = request.getSession();
        sesion.setAttribute("usuario", usuario);
        sesion.setAttribute("email", email);

        // Mensajes de depuración
        System.out.println("Sesión creada: " + sesion.getId());
        System.out.println("Usuario almacenado en sesión: " + sesion.getAttribute("usuario"));
        System.out.println("Email almacenado en sesión: " + sesion.getAttribute("email"));

        // Redirigir al perfil.jsp
        response.sendRedirect(request.getContextPath() + "/styles/perfil.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/styles/register.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Servlet de Registro de Usuario";
    }
}
