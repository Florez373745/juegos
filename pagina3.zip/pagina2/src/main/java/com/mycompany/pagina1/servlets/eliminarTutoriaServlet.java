package com.mycompany.pagina1.servlets;

import Modelo.GestionarTutoria;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "eliminarTutoriaServlet", urlPatterns = {"/eliminarTutoriaServlet"})
public class eliminarTutoriaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener el nombre del curso desde el formulario o enlace
        String nombreCurso = request.getParameter("nombreCurso");

        // Llamar al método para eliminar la tutoría
        GestionarTutoria.eliminarTutoria(nombreCurso);

        // Redirigir nuevamente a la página con la lista
        response.sendRedirect("tutoriasGuardadas.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Servlet para eliminar una tutoría según su nombre";
    }
}
