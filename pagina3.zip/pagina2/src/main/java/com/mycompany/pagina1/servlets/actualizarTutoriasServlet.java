/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.pagina1.servlets;

import Modelo.GestionarTutoria;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "actualizarTutoriasServlet", urlPatterns = {"/actualizarTutoriasServlet"})
public class actualizarTutoriasServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Nombre original de la tutoría (antes de la edición)
        String nombreOriginal = request.getParameter("nombreCurso");

        // Nuevos datos ingresados por el usuario
        String nuevoNombre = request.getParameter("nuevoNombre");
        String nuevoProfesor = request.getParameter("nombreTutor");

        // Actualiza la tutoría
        GestionarTutoria.actualizarTutoria(nombreOriginal, nuevoNombre, nuevoProfesor);

        // Redirige a la página donde se ven las tutorías
        response.sendRedirect("tutoriasGuardadas.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Servlet para actualizar una tutoría";
    }
}
