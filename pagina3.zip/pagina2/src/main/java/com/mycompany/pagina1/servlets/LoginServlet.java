package com.mycompany.pagina1.servlets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        // Obtener la ruta real del archivo usuarios.txt en WEB-INF
        String filePath = getServletContext().getRealPath("/WEB-INF/usuarios.txt");

        // Imprimir la ruta para depuración
        System.out.println("Ruta del archivo: " + filePath);

        // Verificar si el archivo existe
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("⚠ ERROR: El archivo usuarios.txt no existe.");
            response.sendRedirect(request.getContextPath() + "/styles/login.jsp?error=Error en el servidor (archivo no encontrado)");
            return;
        }

        boolean autenticado = false; // Variable para verificar si el usuario es válido

        // Leer el archivo usuarios.txt línea por línea
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    String userTxt = partes[0].trim();
                    String passTxt = partes[1].trim();

                    // Imprimir credenciales para depuración
                    System.out.println("Usuario ingresado: " + usuario);
                    System.out.println("Contraseña ingresada: " + password);
                    System.out.println("Usuario en archivo: " + userTxt);
                    System.out.println("Contraseña en archivo: " + passTxt);

                    if (userTxt.equals(usuario) && passTxt.equals(password)) {
                        autenticado = true;
                        break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/styles/login.jsp?error=Error al leer el archivo");
            return;
        }

        // Si el usuario es válido, iniciar sesión y redirigir al index.jsp
        if (autenticado) {
            HttpSession session = request.getSession();
            session.setAttribute("usuario", usuario);
            System.out.println("✅ Usuario autenticado correctamente.");
            response.sendRedirect(request.getContextPath() + "/styles/index.jsp");
        } else {
            // Si las credenciales no coinciden, redirigir al login con un mensaje de error
            System.out.println("❌ Usuario o contraseña incorrectos.");
            response.sendRedirect(request.getContextPath() + "/styles/login.jsp?error=Usuario o contraseña incorrectos");
        }
    }
}
