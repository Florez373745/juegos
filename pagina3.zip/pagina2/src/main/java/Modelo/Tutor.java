/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author flore
 */
import Modelo.Usuario;
import java.util.ArrayList;

public class Tutor extends Usuario {

    private ArrayList<String> especialidades;
    private ArrayList<String> disponibilidad;

    public Tutor(String nombre, String email) {
        super(nombre, email, "Tutor");
        this.especialidades = new ArrayList<>();
        this.disponibilidad = new ArrayList<>();
    }

    public void agregarEspecialidad(String especialidad) {
        especialidades.add(especialidad);
    }

    public void agregarDisponibilidad(String horario) {
        disponibilidad.add(horario);
    }

    public ArrayList<String> getEspecialidades() {
        return especialidades;
    }

    public ArrayList<String> getDisponibilidad() {
        return disponibilidad;
    }
}
