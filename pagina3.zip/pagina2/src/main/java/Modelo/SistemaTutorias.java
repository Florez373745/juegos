/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author flore
 */
import Modelo.Tutoria;
import Modelo.Usuario;
import Modelo.SesionTutoria;
import java.util.ArrayList;

public class SistemaTutorias {

    private ArrayList<Usuario> usuarios;
    private ArrayList<Tutoria> temas;
    private ArrayList<SesionTutoria> sesiones;

    public SistemaTutorias() {
        this.usuarios = new ArrayList<>();
        this.temas = new ArrayList<>();
        this.sesiones = new ArrayList<>();
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void agregarTema(Tutoria tema) {
        temas.add(tema);
    }

    public void agendarTutoria(SesionTutoria sesion) {
        sesiones.add(sesion);
    }

    public ArrayList<Tutoria> buscarTema(String palabraClave) {
        ArrayList<Tutoria> resultados = new ArrayList<>();
        for (Tutoria tema : temas) {
            if (tema.getNombre().toLowerCase().contains(palabraClave.toLowerCase())) {
                resultados.add(tema);
            }
        }
        return resultados;
    }

    public ArrayList<Tutoria> getTemas() {
        return temas;
    }
    
}
