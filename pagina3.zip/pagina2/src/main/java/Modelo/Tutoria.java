package Modelo;

import java.util.ArrayList;

public class Tutoria {
    private String nombre;
    private String descripcion;
    private String profesor;
    private ArrayList<String> materiales;

    // Constructor principal
    public Tutoria(String nombre, String descripcion, String profesor) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.profesor = profesor;
        this.materiales = new ArrayList<>();
    }

    // Constructor alternativo para búsqueda (sin descripción)
    public Tutoria(String nombre, String profesor) {
        this.nombre = nombre;
        this.profesor = profesor;
        this.descripcion = "";  // Se deja vacío si no hay descripción
        this.materiales = new ArrayList<>();
    }

    // Constructor vacío
    public Tutoria() {
        this.nombre = "";
        this.descripcion = "";
        this.profesor = "";
        this.materiales = new ArrayList<>();
    }

    // Métodos para modificar la tutoría
    public void agregarMaterial(String material) {
        materiales.add(material);
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getProfesor() {
        return profesor;
    }

    public ArrayList<String> getMateriales() {
        return materiales;
    }

    // Setters
    public void setNombre(String nombreCurso) {
        this.nombre = nombreCurso;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setProfesor(String nombreTutor) {
        this.profesor = nombreTutor;
    }

    public void setMateriales(ArrayList<String> materiales) {
        this.materiales = materiales;
    }
}
