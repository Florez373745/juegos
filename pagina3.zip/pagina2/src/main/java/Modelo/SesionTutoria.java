/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Modelo.Tutoria;
import Modelo.Tutor;
/**
 *
 * @author flore
 */import java.time.LocalDateTime;
public class SesionTutoria {
    private String estudiante;
    private Tutor tutor;
    private Tutoria tema;
    private LocalDateTime fecha;

    public SesionTutoria(String estudiante, Tutor tutor, Tutoria tema, LocalDateTime fecha) {
        this.estudiante = estudiante;
        this.tutor = tutor;
        this.tema = tema;
        this.fecha = fecha;
    }

    public String getEstudiante() {
        return estudiante;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public Tutoria getTema() {
        return tema;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }
    
}
