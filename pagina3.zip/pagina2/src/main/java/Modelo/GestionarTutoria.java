package Modelo;

import java.util.ArrayList;

public class GestionarTutoria {
    private static ArrayList<Tutoria> misTutorias = new ArrayList<>();

    public static ArrayList<Tutoria> getMisTutorias() {
        return misTutorias;
    }

    public static void agregarTutoria(String nombre, String profesor) {
        Tutoria tutoria = new Tutoria(nombre, "", profesor); // "" en descripción por ahora
        misTutorias.add(tutoria);
    }

    // Método original para actualizar nombre y profesor
    public static void actualizarTutoria(String nombreOriginal, String nuevoNombre, String nuevoProfesor) {
        for (Tutoria tutoria : misTutorias) {
            if (tutoria.getNombre().equals(nombreOriginal)) {
                tutoria.setNombre(nuevoNombre);
                tutoria.setProfesor(nuevoProfesor);
                break;
            }
        }
    }

    // ✅ Sobrecarga para actualizar solo el profesor, manteniendo el nombre
    public static void actualizarTutoria(String nombreOriginal, String nuevoProfesor) {
        actualizarTutoria(nombreOriginal, nombreOriginal, nuevoProfesor);
    }

    public static void eliminarTutoria(String nombre) {
        misTutorias.removeIf(t -> t.getNombre().equals(nombre));
    }
}
